"use client"

import { useEffect, useState } from "react"

export default function StatusBar() {
  const [time, setTime] = useState<string>("")

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      setTime(now.toLocaleTimeString("en-US", { hour12: false }))
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="border-t-2 border-neon-green bg-gradient-to-t from-secondary/20 to-transparent px-4 py-2 flex items-center justify-between text-xs font-mono text-muted-foreground">
      <div className="flex items-center gap-4">
        <span>MISSION: LANDSLIDE_MONITORING_ALPHA</span>
        <span>ZONE: MOUNTAIN_RIDGE_7</span>
        <span>COVERAGE: 98.7%</span>
      </div>
      <div className="flex items-center gap-4">
        <span>UPTIME: 14h 32m</span>
        <span>{time}</span>
        <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse"></div>
      </div>
    </div>
  )
}
