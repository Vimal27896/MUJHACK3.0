"use client"

import { useEffect, useState } from "react"

export default function DynamicLogo() {
  const [rotation, setRotation] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setRotation((prev) => (prev + 6) % 360)
    }, 50)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative w-12 h-12 flex items-center justify-center">
      {/* Outer rotating ring */}
      <svg
        className="absolute w-full h-full"
        viewBox="0 0 48 48"
        style={{ transform: `rotate(${rotation}deg)`, transition: "transform 0.05s linear" }}
      >
        <circle cx="24" cy="24" r="22" fill="none" stroke="#00ff88" strokeWidth="2" opacity="0.8" />
        <circle cx="24" cy="24" r="18" fill="none" stroke="#00ffff" strokeWidth="1.5" opacity="0.6" />
      </svg>

      {/* Center drone icon */}
      <svg className="relative w-6 h-6 z-10" viewBox="0 0 24 24" fill="none">
        {/* Drone body */}
        <rect x="8" y="10" width="8" height="4" fill="#ff6600" />
        {/* Propellers */}
        <circle cx="6" cy="8" r="2" fill="#00ff88" />
        <circle cx="18" cy="8" r="2" fill="#00ff88" />
        <circle cx="6" cy="16" r="2" fill="#00ffff" />
        <circle cx="18" cy="16" r="2" fill="#00ffff" />
        {/* Center dot */}
        <circle cx="12" cy="12" r="1.5" fill="#ff6600" />
      </svg>

      {/* Pulsing glow effect */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: "radial-gradient(circle, rgba(0,255,136,0.3) 0%, transparent 70%)",
          animation: "pulse 2s ease-in-out infinite",
        }}
      />
    </div>
  )
}
