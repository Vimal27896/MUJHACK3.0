"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Upload, Zap, Info, AlertTriangle } from "lucide-react"

interface UploadedImage {
  id: string
  type: "h5" | "sar" | "terrain" | "rgb" | "multispectral"
  name: string
  data: string
  format: string
}

interface AnalysisResult {
  imageId: string
  type: string
  format: string
  riskScore: number
  confidence: number
  changeIntensity: "critical" | "high" | "moderate" | "low" | "minimal"
  characteristics: string[]
  anomalies: string[]
  detailedFindings: {
    deformation: string
    stability: string
    moisture: string
    vegetation: string
  }
}

export default function ImageComparison() {
  const [images, setImages] = useState<UploadedImage[]>([])
  const [selectedImages, setSelectedImages] = useState<string[]>([])
  const [analyzing, setAnalyzing] = useState(false)
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const detectImageFormat = (fileName: string): { type: string; format: string } => {
    const lowerName = fileName.toLowerCase()

    if (lowerName.endsWith(".h5") || lowerName.endsWith(".hdf5")) {
      return { type: "h5", format: "HDF5 (Hierarchical Data Format)" }
    }
    if (lowerName.includes("sar") || lowerName.endsWith(".sar")) {
      return { type: "sar", format: "SAR (Synthetic Aperture Radar)" }
    }
    if (lowerName.includes("dem") || lowerName.includes("terrain") || lowerName.endsWith(".tif")) {
      return { type: "terrain", format: "GeoTIFF (Terrain/DEM)" }
    }
    if (lowerName.endsWith(".tif") || lowerName.endsWith(".tiff")) {
      return { type: "multispectral", format: "GeoTIFF (Multispectral)" }
    }
    if (lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")) {
      return { type: "rgb", format: "JPEG (RGB)" }
    }
    if (lowerName.endsWith(".png")) {
      return { type: "rgb", format: "PNG (RGB)" }
    }
    return { type: "terrain", format: "Unknown Format" }
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        const { type, format } = detectImageFormat(file.name)

        const newImage: UploadedImage = {
          id: Math.random().toString(36),
          type: type as any,
          name: file.name,
          data: event.target?.result as string,
          format,
        }

        setImages((prev) => [...prev, newImage])
      }
      reader.readAsDataURL(file)
    })
  }

  const toggleImageSelection = (id: string) => {
    setSelectedImages((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  const runAIDetection = async () => {
    if (selectedImages.length < 1) return
    setAnalyzing(true)

    const selectedImageData = images.filter((img) => selectedImages.includes(img.id))

    // Simulate AI analysis based on image types with realistic risk metrics
    const results: AnalysisResult[] = selectedImageData.map((img) => {
      let riskScore = 0
      let confidence = 0
      let changeIntensity: "critical" | "high" | "moderate" | "low" | "minimal" = "low"
      let characteristics: string[] = []
      let anomalies: string[] = []
      let detailedFindings = {
        deformation: "",
        stability: "",
        moisture: "",
        vegetation: "",
      }

      if (img.type === "h5") {
        riskScore = 72
        confidence = 94
        changeIntensity = "high"
        characteristics = [
          "Multi-layer elevation data",
          "Temporal resolution: 12 months",
          "Vertical accuracy: ±5cm",
          "Coverage: 2,450 km²",
        ]
        anomalies = [
          "Subsidence detected: -2.3cm/month",
          "Slope instability zone: 15% area",
          "Water saturation anomaly: +8%",
        ]
        detailedFindings = {
          deformation:
            "Significant vertical displacement detected in valley regions. Rate of change: -2.3cm/month indicates accelerating subsidence.",
          stability:
            "Slope stability index dropped 18% compared to previous survey. Critical zones identified in 3 locations.",
          moisture:
            "Soil moisture increased by 8% in subsurface layers. Correlation with deformation patterns suggests groundwater influence.",
          vegetation:
            "Vegetation stress detected in 12% of monitored area. Likely caused by ground movement and moisture changes.",
        }
      } else if (img.type === "sar") {
        riskScore = 58
        confidence = 87
        changeIntensity = "moderate"
        characteristics = [
          "Radar backscatter: VV/VH polarization",
          "Phase coherence: 0.87",
          "Spatial resolution: 10m",
          "Temporal baseline: 24 days",
        ]
        anomalies = [
          "Deformation pattern: 3.2cm line-of-sight displacement",
          "Moisture change: +12% surface water content",
          "Surface roughness variance: 18% increase",
        ]
        detailedFindings = {
          deformation:
            "SAR interferometry reveals 3.2cm displacement in LOS direction. Pattern suggests localized subsidence rather than regional movement.",
          stability:
            "Coherence loss in 8% of image indicates active deformation zones. Stability rating: MODERATE CONCERN.",
          moisture:
            "Backscatter intensity increase indicates surface moisture accumulation. Likely from recent precipitation and poor drainage.",
          vegetation:
            "Vegetation water content shows 12% increase. Radar signature changes correlate with ground deformation.",
        }
      } else if (img.type === "terrain") {
        riskScore = 65
        confidence = 91
        changeIntensity = "high"
        characteristics = [
          "Digital Elevation Model (DEM)",
          "Slope range: 5-52°",
          "Aspect: Multi-directional",
          "Spatial resolution: 30m",
        ]
        anomalies = [
          "Steep slope zone: 28% of area >30°",
          "Drainage pattern anomaly: 5 new gullies",
          "Erosion indicators: 15% surface change",
        ]
        detailedFindings = {
          deformation: "Terrain elevation changed by average 1.2m. Maximum change: 4.8m in valley sections.",
          stability:
            "Slope angle analysis shows 28% of terrain exceeds safe threshold (>30°). Landslide susceptibility: HIGH.",
          moisture:
            "Drainage pattern analysis indicates water accumulation zones. 5 new gullies suggest active erosion.",
          vegetation: "Terrain changes correlate with vegetation loss in 18% of monitored area.",
        }
      } else if (img.type === "rgb") {
        riskScore = 45
        confidence = 82
        changeIntensity = "moderate"
        characteristics = [
          "RGB color channels: 8-bit",
          "Vegetation index (NDVI): 0.62",
          "Cloud cover: 2%",
          "Spatial resolution: 15m",
        ]
        anomalies = [
          "Vegetation stress: 22% area affected",
          "Landslide scar: 0.8 km² visible",
          "Water body change: +5% surface area",
        ]
        detailedFindings = {
          deformation: "Visual evidence of ground displacement. Landslide scar clearly visible covering 0.8 km².",
          stability:
            "Vegetation stress patterns indicate ground instability. 22% of vegetation shows stress indicators.",
          moisture: "Water body expanded by 5% surface area. New water accumulation zones detected.",
          vegetation: "NDVI decreased by 0.18 compared to previous survey. Indicates vegetation health degradation.",
        }
      } else if (img.type === "multispectral") {
        riskScore = 68
        confidence = 89
        changeIntensity = "high"
        characteristics = [
          "Spectral bands: 11 channels",
          "Wavelength range: 0.4-2.3μm",
          "Radiometric resolution: 12-bit",
          "Spatial resolution: 20m",
        ]
        anomalies = [
          "Mineral composition shift: 8% change",
          "Thermal anomaly: +3.2°C surface temp",
          "Spectral signature variance: 24%",
        ]
        detailedFindings = {
          deformation:
            "Spectral analysis reveals subsurface changes. Mineral composition shift suggests ground movement and weathering.",
          stability:
            "Thermal anomaly (+3.2°C) correlates with deformation zones. Indicates active geological processes.",
          moisture: "Moisture absorption bands show 15% increase. Suggests groundwater rise or surface saturation.",
          vegetation:
            "Spectral vegetation indices show 24% variance. Multiple stress indicators detected across bands.",
        }
      }

      return {
        imageId: img.id,
        type: img.type.toUpperCase(),
        format: img.format,
        riskScore,
        confidence,
        changeIntensity,
        characteristics,
        anomalies,
        detailedFindings,
      }
    })

    await new Promise((resolve) => setTimeout(resolve, 2000))
    setAnalysisResults(results)
    setAnalyzing(false)
  }

  const removeImage = (id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id))
    setSelectedImages((prev) => prev.filter((i) => i !== id))
    setAnalysisResults((prev) => prev.filter((r) => r.imageId !== id))
  }

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-red-500"
    if (score >= 50) return "text-orange-500"
    if (score >= 30) return "text-yellow-500"
    return "text-green-500"
  }

  const getChangeColor = (intensity: string) => {
    switch (intensity) {
      case "critical":
        return "text-red-600 bg-red-500/10"
      case "high":
        return "text-orange-500 bg-orange-500/10"
      case "moderate":
        return "text-yellow-500 bg-yellow-500/10"
      case "low":
        return "text-green-500 bg-green-500/10"
      default:
        return "text-cyan-500 bg-cyan-500/10"
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="text-xs text-muted-foreground mb-2 font-mono tracking-widest">▌ AI IMAGE ANALYSIS</div>

      {/* Format Info */}
      <div className="text-[10px] text-muted-foreground mb-2 p-1 border border-border/30 rounded-sm bg-secondary/10">
        <div className="flex items-start gap-1">
          <Info size={12} className="mt-0.5 flex-shrink-0" />
          <span>Formats: H5/HDF5, SAR, GeoTIFF, RGB (JPG/PNG), Multispectral</span>
        </div>
      </div>

      {/* Upload Area */}
      <div
        className="border-2 border-neon-cyan rounded-sm p-2 mb-2 cursor-pointer hover:bg-secondary/30 transition-colors"
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".h5,.hdf5,.sar,.tif,.tiff,.jpg,.jpeg,.png"
          onChange={handleFileUpload}
          className="hidden"
        />
        <div className="flex items-center justify-center gap-2 py-2">
          <Upload size={14} className="text-neon-cyan" />
          <span className="text-xs text-muted-foreground font-mono">UPLOAD IMAGES</span>
        </div>
      </div>

      {/* Images List */}
      <div className="flex-1 overflow-y-auto mb-2 space-y-1">
        {images.map((img) => (
          <div key={img.id}>
            <div
              className={`p-2 rounded-sm text-xs font-mono cursor-pointer transition-all ${
                selectedImages.includes(img.id)
                  ? "border-2 border-neon-green bg-secondary/30"
                  : "border-2 border-border/30 bg-secondary/10 hover:bg-secondary/20"
              }`}
              onClick={() => toggleImageSelection(img.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-neon-green truncate">{img.name}</div>
                  <div className="text-muted-foreground text-[10px]">{img.format}</div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeImage(img.id)
                  }}
                  className="text-muted-foreground hover:text-neon-orange ml-1"
                >
                  ✕
                </button>
              </div>
            </div>

            {selectedImages.includes(img.id) && analysisResults.find((r) => r.imageId === img.id) && (
              <div className="p-2 bg-secondary/20 border border-neon-orange/50 rounded-sm text-[10px] space-y-2 mb-1">
                {analysisResults
                  .filter((r) => r.imageId === img.id)
                  .map((result) => (
                    <div key={result.imageId} className="space-y-2">
                      <div className="text-neon-orange font-bold flex items-center gap-1">
                        <AlertTriangle size={12} />
                        {result.type} ANALYSIS
                      </div>

                      {/* Risk Metrics */}
                      <div className="grid grid-cols-3 gap-1 bg-secondary/30 p-1 rounded">
                        <div className="text-center">
                          <div className={`text-sm font-bold ${getRiskColor(result.riskScore)}`}>
                            {result.riskScore}%
                          </div>
                          <div className="text-muted-foreground text-[9px]">RISK SCORE</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm font-bold text-neon-cyan">{result.confidence}%</div>
                          <div className="text-muted-foreground text-[9px]">CONFIDENCE</div>
                        </div>
                        <div className={`text-center px-1 rounded ${getChangeColor(result.changeIntensity)}`}>
                          <div className="text-sm font-bold uppercase">{result.changeIntensity}</div>
                          <div className="text-muted-foreground text-[9px]">INTENSITY</div>
                        </div>
                      </div>

                      {/* Characteristics */}
                      <div>
                        <span className="text-neon-cyan font-bold">📊 Characteristics:</span>
                        <ul className="ml-2 text-[9px] text-muted-foreground space-y-0.5">
                          {result.characteristics.map((char, i) => (
                            <li key={i}>• {char}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Anomalies */}
                      <div>
                        <span className="text-neon-orange font-bold">⚠ Anomalies Detected:</span>
                        <ul className="ml-2 text-[9px] text-muted-foreground space-y-0.5">
                          {result.anomalies.map((anom, i) => (
                            <li key={i}>🔴 {anom}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Detailed Findings */}
                      <div className="bg-secondary/40 p-1 rounded border border-border/30 space-y-1">
                        <div className="text-neon-green font-bold text-[9px]">DETAILED FINDINGS:</div>
                        <div className="text-[8px] text-muted-foreground space-y-1">
                          <div>
                            <span className="text-neon-cyan">Deformation:</span> {result.detailedFindings.deformation}
                          </div>
                          <div>
                            <span className="text-neon-orange">Stability:</span> {result.detailedFindings.stability}
                          </div>
                          <div>
                            <span className="text-neon-cyan">Moisture:</span> {result.detailedFindings.moisture}
                          </div>
                          <div>
                            <span className="text-neon-green">Vegetation:</span> {result.detailedFindings.vegetation}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* AI Detection Button */}
      <button
        onClick={runAIDetection}
        disabled={selectedImages.length < 1 || analyzing}
        className={`w-full py-2 rounded-sm text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
          analyzing
            ? "border-2 border-neon-orange bg-secondary/20 text-neon-orange"
            : selectedImages.length < 1
              ? "border-2 border-border/30 text-muted-foreground opacity-50 cursor-not-allowed"
              : "border-2 border-neon-green bg-secondary/20 text-neon-green hover:bg-secondary/40"
        }`}
      >
        <Zap size={12} />
        {analyzing ? "ANALYZING..." : "RUN AI DETECTION"}
      </button>
    </div>
  )
}
