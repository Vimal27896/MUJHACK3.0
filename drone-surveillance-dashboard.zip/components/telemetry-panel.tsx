"use client"

import { useEffect, useState } from "react"

interface TelemetryData {
  altitude: number
  speed: number
  battery: number
  temperature: number
  signal: number
}

export default function TelemetryPanel() {
  const [telemetry, setTelemetry] = useState<TelemetryData>({
    altitude: 245,
    speed: 18.5,
    battery: 87,
    temperature: 42,
    signal: 95,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry((prev) => ({
        altitude: prev.altitude + (Math.random() - 0.5) * 10,
        speed: Math.max(0, prev.speed + (Math.random() - 0.5) * 5),
        battery: Math.max(0, prev.battery - Math.random() * 0.5),
        temperature: prev.temperature + (Math.random() - 0.5) * 2,
        signal: Math.max(0, Math.min(100, prev.signal + (Math.random() - 0.5) * 3)),
      }))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const TelemetryItem = ({
    label,
    value,
    unit,
    color,
  }: {
    label: string
    value: number
    unit: string
    color: string
  }) => (
    <div className="mb-3 pb-3 border-b border-border/30">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs text-muted-foreground font-mono">{label}</span>
        <span className={`text-sm font-bold font-mono ${color}`}>
          {value.toFixed(1)} {unit}
        </span>
      </div>
      <div className="w-full h-2 bg-secondary rounded-full overflow-hidden border border-border/50">
        <div
          className={`h-full transition-all duration-300 ${color.replace("text-", "bg-")}`}
          style={{ width: `${Math.min(100, (value / 100) * 100)}%` }}
        />
      </div>
    </div>
  )

  return (
    <div>
      <div className="text-xs text-muted-foreground mb-3 font-mono tracking-widest">▌ TELEMETRY DATA</div>
      <TelemetryItem label="ALTITUDE" value={telemetry.altitude} unit="m" color="neon-text-green" />
      <TelemetryItem label="VELOCITY" value={telemetry.speed} unit="m/s" color="neon-text-cyan" />
      <TelemetryItem label="BATTERY" value={telemetry.battery} unit="%" color="neon-text-orange" />
      <TelemetryItem label="TEMP" value={telemetry.temperature} unit="°C" color="neon-text-green" />
      <TelemetryItem label="SIGNAL" value={telemetry.signal} unit="%" color="neon-text-cyan" />
    </div>
  )
}
