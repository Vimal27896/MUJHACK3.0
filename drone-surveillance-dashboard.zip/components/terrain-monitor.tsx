"use client"

import { useState, useEffect } from "react"

interface TerrainData {
  slopeAngle: number
  soilMoisture: number
  riskPercentage: number
  stability: string
}

export default function TerrainMonitor() {
  const [terrain, setTerrain] = useState<TerrainData>({
    slopeAngle: 34.5,
    soilMoisture: 62.3,
    riskPercentage: 28.7,
    stability: "MODERATE",
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setTerrain((prev) => ({
        slopeAngle: Math.max(0, Math.min(90, prev.slopeAngle + (Math.random() - 0.5) * 3)),
        soilMoisture: Math.max(0, Math.min(100, prev.soilMoisture + (Math.random() - 0.5) * 4)),
        riskPercentage: Math.max(0, Math.min(100, prev.riskPercentage + (Math.random() - 0.5) * 2)),
        stability: prev.stability,
      }))
    }, 1500)

    return () => clearInterval(interval)
  }, [])

  const getRiskColor = (risk: number) => {
    if (risk < 20) return "neon-text-green"
    if (risk < 50) return "neon-text-orange"
    return "neon-text-cyan"
  }

  return (
    <div>
      <div className="text-xs text-muted-foreground mb-3 font-mono tracking-widest">▌ TERRAIN ANALYSIS</div>

      <div className="space-y-3">
        {/* Slope Angle */}
        <div className="glow-border-green rounded-sm p-2 bg-secondary/20">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground font-mono">SLOPE ANGLE</span>
            <span className="neon-text-green font-mono text-sm">{terrain.slopeAngle.toFixed(1)}°</span>
          </div>
          <div className="w-full h-2 bg-secondary rounded-full overflow-hidden border border-border/50">
            <div
              className="h-full bg-neon-green transition-all duration-300"
              style={{ width: `${(terrain.slopeAngle / 90) * 100}%` }}
            />
          </div>
        </div>

        {/* Soil Moisture */}
        <div className="glow-border-cyan rounded-sm p-2 bg-secondary/20">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground font-mono">SOIL MOISTURE</span>
            <span className="neon-text-cyan font-mono text-sm">{terrain.soilMoisture.toFixed(1)}%</span>
          </div>
          <div className="w-full h-2 bg-secondary rounded-full overflow-hidden border border-border/50">
            <div
              className="h-full bg-neon-cyan transition-all duration-300"
              style={{ width: `${terrain.soilMoisture}%` }}
            />
          </div>
        </div>

        {/* Risk Percentage */}
        <div className="glow-border-orange rounded-sm p-2 bg-secondary/20">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground font-mono">LANDSLIDE RISK</span>
            <span className={`font-mono text-sm ${getRiskColor(terrain.riskPercentage)}`}>
              {terrain.riskPercentage.toFixed(1)}%
            </span>
          </div>
          <div className="w-full h-2 bg-secondary rounded-full overflow-hidden border border-border/50">
            <div
              className={`h-full transition-all duration-300 ${
                terrain.riskPercentage < 20
                  ? "bg-neon-green"
                  : terrain.riskPercentage < 50
                    ? "bg-neon-orange"
                    : "bg-neon-cyan"
              }`}
              style={{ width: `${terrain.riskPercentage}%` }}
            />
          </div>
        </div>

        {/* Stability Status */}
        <div className="glow-border rounded-sm p-2 bg-secondary/20">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground font-mono">STABILITY STATUS</span>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-neon-orange animate-pulse"></div>
              <span className="neon-text-orange font-mono text-sm">{terrain.stability}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
