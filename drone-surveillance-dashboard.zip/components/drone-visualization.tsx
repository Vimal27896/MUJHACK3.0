"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"

interface DroneVisualizationProps {
  active: boolean
}

export default function DroneVisualization({ active }: DroneVisualizationProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const droneRef = useRef<THREE.Group | null>(null)
  const propellersRef = useRef<THREE.Mesh[]>([])

  useEffect(() => {
    if (!containerRef.current) return

    // Scene setup
    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x0a0a0a)
    sceneRef.current = scene

    // Camera
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000,
    )
    camera.position.set(0, 5, 8)
    camera.lookAt(0, 0, 0)

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    renderer.setClearColor(0x0a0a0a, 1)
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x00ff88, 0.4)
    scene.add(ambientLight)

    const pointLight = new THREE.PointLight(0x00ffff, 1.2)
    pointLight.position.set(5, 10, 5)
    scene.add(pointLight)

    const pointLight2 = new THREE.PointLight(0xff6600, 0.8)
    pointLight2.position.set(-5, 8, -5)
    scene.add(pointLight2)

    const drone = new THREE.Group()
    droneRef.current = drone

    // Drone body - main chassis
    const bodyGeometry = new THREE.BoxGeometry(1.2, 0.4, 1.2)
    const wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0x00ff88,
      wireframe: true,
      emissive: 0x00ff88,
    })
    const body = new THREE.Mesh(bodyGeometry, wireframeMaterial)
    drone.add(body)

    // Camera gimbal on bottom
    const gimbalGeometry = new THREE.SphereGeometry(0.15, 8, 8)
    const gimbalMaterial = new THREE.MeshBasicMaterial({
      color: 0x00ffff,
      wireframe: true,
      emissive: 0x00ffff,
    })
    const gimbal = new THREE.Mesh(gimbalGeometry, gimbalMaterial)
    gimbal.position.y = -0.3
    drone.add(gimbal)

    // Sensor array on top
    const sensorGeometry = new THREE.BoxGeometry(0.8, 0.1, 0.8)
    const sensorMaterial = new THREE.MeshBasicMaterial({
      color: 0xff6600,
      wireframe: true,
      emissive: 0xff6600,
    })
    const sensor = new THREE.Mesh(sensorGeometry, sensorMaterial)
    sensor.position.y = 0.3
    drone.add(sensor)

    // Antenna
    const antennaGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.6, 8)
    const antennaMaterial = new THREE.MeshBasicMaterial({
      color: 0x00ffff,
      wireframe: true,
    })
    const antenna = new THREE.Mesh(antennaGeometry, antennaMaterial)
    antenna.position.set(0.4, 0.4, 0)
    drone.add(antenna)

    // Drone arms with enhanced geometry
    const armGeometry = new THREE.CylinderGeometry(0.08, 0.08, 1.8, 8)
    const armPositions = [
      [-0.8, 0, -0.8],
      [0.8, 0, -0.8],
      [-0.8, 0, 0.8],
      [0.8, 0, 0.8],
    ]

    const propellers: THREE.Mesh[] = []

    armPositions.forEach((pos) => {
      const arm = new THREE.Mesh(armGeometry, wireframeMaterial)
      arm.position.set(pos[0], pos[1], pos[2])
      drone.add(arm)

      const propGeometry = new THREE.CylinderGeometry(0.4, 0.4, 0.08, 32)
      const propMaterial = new THREE.MeshBasicMaterial({
        color: 0x00ffff,
        wireframe: true,
        emissive: 0x00ffff,
      })
      const propeller = new THREE.Mesh(propGeometry, propMaterial)
      propeller.position.y = 0.9
      arm.add(propeller)
      propellers.push(propeller)

      // Motor housing
      const motorGeometry = new THREE.CylinderGeometry(0.12, 0.12, 0.2, 8)
      const motor = new THREE.Mesh(motorGeometry, wireframeMaterial)
      motor.position.y = 0.75
      arm.add(motor)
    })

    propellersRef.current = propellers
    scene.add(drone)

    // Terrain (Grid)
    const gridHelper = new THREE.GridHelper(20, 20, 0x00ff88, 0x00ffff)
    gridHelper.position.y = -3
    scene.add(gridHelper)

    // Scan lines effect - multiple layers
    const scanLines: THREE.Mesh[] = []
    for (let i = 0; i < 3; i++) {
      const scanGeometry = new THREE.PlaneGeometry(20, 0.15)
      const scanMaterial = new THREE.MeshBasicMaterial({
        color: 0x00ffff,
        emissive: 0x00ffff,
        transparent: true,
        opacity: 0.2,
      })
      const scanLine = new THREE.Mesh(scanGeometry, scanMaterial)
      scanLine.position.y = -2.5
      scanLine.userData.offset = i * 0.5
      scene.add(scanLine)
      scanLines.push(scanLine)
    }

    // Radar circles
    const radarGroup = new THREE.Group()
    radarGroup.position.y = -2.9
    for (let i = 1; i <= 3; i++) {
      const radarGeometry = new THREE.BufferGeometry()
      const points = []
      for (let j = 0; j <= 64; j++) {
        const angle = (j / 64) * Math.PI * 2
        points.push(Math.cos(angle) * i * 2, 0, Math.sin(angle) * i * 2)
      }
      radarGeometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(points), 3))
      const radarMaterial = new THREE.LineBasicMaterial({
        color: 0x00ff88,
        transparent: true,
        opacity: 0.3,
      })
      const radarLine = new THREE.Line(radarGeometry, radarMaterial)
      radarGroup.add(radarLine)
    }
    scene.add(radarGroup)

    // Animation loop
    let animationId: number
    const animate = () => {
      animationId = requestAnimationFrame(animate)

      if (active && drone) {
        const time = Date.now() * 0.0005
        drone.rotation.y += 0.003
        drone.position.y = Math.sin(time) * 0.8 + Math.cos(time * 0.7) * 0.3
        drone.position.x = Math.sin(time * 0.6) * 1.5
        drone.position.z = Math.cos(time * 0.8) * 1.5

        // Propeller rotation
        propellers.forEach((prop, index) => {
          prop.rotation.x += index % 2 === 0 ? 0.3 : -0.3
        })

        // Gimbal rotation
        const gimbalChild = drone.children.find(
          (child) => child instanceof THREE.Mesh && (child as any).geometry instanceof THREE.SphereGeometry,
        )
        if (gimbalChild) {
          gimbalChild.rotation.x = Math.sin(time * 1.5) * 0.3
          gimbalChild.rotation.z = Math.cos(time * 1.2) * 0.3
        }
      }

      // Scan line animation
      scanLines.forEach((line, index) => {
        line.position.y = -3 + Math.sin(Date.now() * 0.003 + index * 0.5) * 3
        line.material.opacity = 0.2 + Math.sin(Date.now() * 0.005 + index) * 0.1
      })

      // Radar rotation
      radarGroup.rotation.z += 0.01

      renderer.render(scene, camera)
    }

    animate()

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current) return
      const width = containerRef.current.clientWidth
      const height = containerRef.current.clientHeight
      camera.aspect = width / height
      camera.updateProjectionMatrix()
      renderer.setSize(width, height)
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationId)
      containerRef.current?.removeChild(renderer.domElement)
      renderer.dispose()
    }
  }, [active])

  return (
    <div className="w-full h-full">
      <div className="text-xs text-muted-foreground mb-2 font-mono">DRONE SCAN ACTIVE</div>
      <div ref={containerRef} className="w-full h-[calc(100%-24px)] rounded-sm" />
    </div>
  )
}
