"use client"

import { useState } from "react"
import DroneVisualization from "@/components/drone-visualization"
import TelemetryPanel from "@/components/telemetry-panel"
import TerrainMonitor from "@/components/terrain-monitor"
import ImageComparison from "@/components/image-comparison"
import StatusBar from "@/components/status-bar"
import DynamicLogo from "@/components/dynamic-logo"

export default function DroneDashboard() {
  const [droneActive, setDroneActive] = useState(true)
  const [scanMode, setScanMode] = useState("terrain")

  return (
    <div className="w-full h-screen bg-background text-foreground holographic-grid overflow-hidden">
      {/* Header */}
      <div className="border-b-2 border-neon-green bg-gradient-to-b from-secondary/20 to-transparent p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DynamicLogo />
            <div>
              <h1 className="text-xl font-bold neon-text-green tracking-widest">SENTINEL DRONE</h1>
              <span className="text-xs text-muted-foreground">v4.2.1 | ADVANCED TERRAIN MONITORING</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>SYSTEM STATUS: OPERATIONAL</span>
            <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-12 gap-2 p-4 h-[calc(100vh-80px)] overflow-hidden">
        {/* Left Panel - Drone Visualization */}
        <div className="col-span-5 glow-border-green rounded-sm p-3 bg-secondary/10 overflow-hidden">
          <DroneVisualization active={droneActive} />
        </div>

        {/* Center Panel - Telemetry & Terrain */}
        <div className="col-span-4 flex flex-col gap-2 overflow-hidden">
          <div className="flex-1 glow-border-cyan rounded-sm p-3 bg-secondary/10 overflow-y-auto">
            <TelemetryPanel />
          </div>
          <div className="flex-1 glow-border-orange rounded-sm p-3 bg-secondary/10 overflow-y-auto">
            <TerrainMonitor />
          </div>
        </div>

        {/* Right Panel - Image Comparison */}
        <div className="col-span-3 glow-border rounded-sm p-3 bg-secondary/10 overflow-hidden flex flex-col">
          <ImageComparison />
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar />
    </div>
  )
}
